# **EJERCICIO 1**

#### **Entrada:**

* Tres valores numéricos enteros (X, Y, Z)

#### **Salida:**

* Impresión de los valores de X, Y y Z

### Pasos:

1. **Inicio:**
   * Mostramos al usuario un mensaje para que ingrese el valor de X.
2. **Lectura de X:**
   * Leemos el valor de X utilizando la función `scanf `y la especificación de formato `%d`.
3. **Mostrar mensaje para Y:**
   * Mostramos al usuario un mensaje para que ingrese el valor de Y.
4. **Lectura de Y:**
   * Leemos el valor de Y utilizando la función `scanf` y la especificación de formato `%d`.
5. **Mostrar mensaje para Z:**
   * Mostramos al usuario un mensaje para que ingrese el valor de Z.
6. **Lectura de Z:**
   * LLeemos el valor de Z utilizando la función `scanf` y la especificación de formato `%d`.
7. **Mostrar resultados:**
   * Imprimir un mensaje que indique los valores de X, Y y Z utilizando la función `printf`.
8. **Fin:**
   * Devolver el valor 0 para indicar la finalización exitosa del programa.
