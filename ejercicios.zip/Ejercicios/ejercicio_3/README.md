# EJERCICIO 3

#### **Entrada:**

* La inicial del nombre del usuario (inicialNombre)

#### **Salida:**

* Impresión de la inicial del nombre del usuario

#### **Pasos:**

1. **Inicio:**
   * Mostrar un mensaje al usuario para que ingrese la inicial de su nombre.
2. **Lectura de la inicial:**
   * Leer la inicial utilizando la función `scanf` y la especificación de formato `%c`.
3. **Mostrar resultado:**
   * Imprimir un mensaje que indique la inicial del nombre del usuario utilizando la función `printf`.
4. **Fin:**
   * Devolver el valor 0 para indicar la finalización exitosa del programa.
