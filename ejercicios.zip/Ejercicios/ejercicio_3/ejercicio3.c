#include <stdio.h>

int main()
{
    char inicialNombre;

    printf("Ingrese la inicial de su nombre: ");
    scanf("%c", &inicialNombre);

    printf("La inicial de su nombre es: %c\n", inicialNombre);

    return 0;
}