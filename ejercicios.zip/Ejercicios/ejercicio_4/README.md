# **EJERCICIO 4**

#### **Entrada:**

* Dos números de tipo `double` (x e y)

#### **Salida:**

* Resultado de la división de x por y (respuesta)

#### **Pasos:**

1. **Inicio:**
   * Mostrar un mensaje al usuario para que ingrese el valor de x.
2. **Lectura de x:**
   * Leer el valor de x utilizando la función `scanf` y la especificación de formato `%lf`.
3. **Mostrar mensaje para y:**
   * Mostrar un mensaje al usuario para que ingrese el valor de y.
4. **Lectura de y:**
   * Leer el valor de y utilizando la función `scanf` y la especificación de formato `%lf`.
5. **Cálculo de la división:**
   * Calcular el resultado de la división de x por y utilizando la variable `respuesta`.
6. **Mostrar resultado:**
   * Imprimir un mensaje que indique el resultado de la división utilizando la función `printf`.
7. **Fin:**
   * Devolver el valor 0 para indicar la finalización exitosa del programa.
