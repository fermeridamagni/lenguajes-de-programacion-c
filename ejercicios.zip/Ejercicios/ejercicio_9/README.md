# EJERCICIO 9

#### **Entrada:**

* La edad de la persona (edad)

#### **Salida:**

* Mensaje que indica la etapa de la vida de la persona

#### **Pasos:**

1. **Inicio:**
   * Mostrar un mensaje al usuario para que ingrese su edad.
2. **Lectura de la edad:**
   * Leer la edad utilizando la función `scanf` y la especificación de formato `%d`.
3. **Evaluación de la edad:**
   * Comparar la edad con diferentes rangos para determinar la etapa de la vida.
4. **Mostrar resultado:**
   * Imprimir un mensaje que indique la etapa de la vida de la persona según la comparación realizada.
5. **Fin:**
   * Devolver el valor 0 para indicar la finalización exitosa del programa.
